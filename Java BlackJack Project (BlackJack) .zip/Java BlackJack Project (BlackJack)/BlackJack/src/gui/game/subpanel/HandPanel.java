package gui.game.subpanel;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;

import actors.Player;
import game.Game;
import gui.game.GamePanel;
import materials.Card;

public class HandPanel extends JPanel{
	//JLabel cardIcon;
	GamePanel gamePanel;
	public HandPanel(GamePanel gamePanel){
		setBackground(new Color(0, 128, 0));
		this.gamePanel = gamePanel;
//		ImageIcon ic = new ImageIcon(System.getProperty("user.dir") + "\\img\\ka.png");
		setLayout(new FlowLayout());
//		JLabel cardIcon = new JLabel(ic);
//		add(cardIcon);
		Border blackline = BorderFactory.createLineBorder(Color.black);
		setBorder(blackline);
		setPreferredSize(new Dimension(1500,400));
	}	
	public void update() {
		removeAll();
		revalidate();
		repaint();
		Game game = gamePanel.getGame();
		int turn = game.getTurn();
		Player player = (Player)(game.getActors()[turn]);
		for(Card c : player.getCards()) {
			String directory = System.getProperty("user.dir") + "\\img\\" + c.imageName() + ".png";
			ImageIcon ic = new ImageIcon(directory);
			JLabel cardIcon = new JLabel(ic);
			add(cardIcon);
		}
		gamePanel.getMainFrame().pack();
	}
}
