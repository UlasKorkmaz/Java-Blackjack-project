package gui.game.subpanel;

import javax.swing.JPanel;

import actors.Player;
import gui.game.GamePanel;
import gui.game.user.DealerPanel;
import gui.game.user.PlayerPanel;

public class UsersContainer extends JPanel{
	GamePanel gamePanel;
	DealerPanel dealerPanel;
	PlayerPanel[] playerPanels;
	public UsersContainer(GamePanel gamePanel, DealerPanel dealerPanel, PlayerPanel[] playerPanels) {
		this.gamePanel = gamePanel;
		this.dealerPanel = dealerPanel;
		this.playerPanels = playerPanels;
		add(this.dealerPanel);
		for(PlayerPanel p : this.playerPanels)
			add(p);
	}
	public DealerPanel getDealerPanel() {
		return dealerPanel;
	}
	public PlayerPanel[] getPlayerPanels() {
		return playerPanels;
	}
	public void setDealerPanel(DealerPanel dealerPanel) {
		this.dealerPanel = dealerPanel;
	}
	public void setPlayerPanels(PlayerPanel[] playerPanels) {
		this.playerPanels = playerPanels;
	}
	
	
	
	public void addNewPlayer(Player player) {
		PlayerPanel[] newPlayerPanels = new PlayerPanel[playerPanels.length + 1];
		for(int i = 0; i < playerPanels.length; i++)
			newPlayerPanels[i] = playerPanels[i];
		newPlayerPanels[newPlayerPanels.length - 1] = new PlayerPanel(gamePanel, player);
		add(newPlayerPanels[newPlayerPanels.length - 1]);
		playerPanels = newPlayerPanels;
		gamePanel.getMainFrame().pack();
		revalidate();
		repaint();
	}
	public void removePlayer() {
		if(playerPanels.length == 0)
			return;
		PlayerPanel[] newPlayerPanels = new PlayerPanel[playerPanels.length - 1];
		for(int i = 0; i < playerPanels.length - 1; i++)
			newPlayerPanels[i] = playerPanels[i];
		remove(playerPanels[playerPanels.length - 1]);
		playerPanels = newPlayerPanels;
		gamePanel.getMainFrame().pack();
		revalidate();
		repaint();
	}
}
