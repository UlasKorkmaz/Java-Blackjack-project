package gui.game.user;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.Border;

import actors.Actor;
import gui.game.GamePanel;

public abstract class UserPanel extends JPanel{
	GridBagLayout layout;
	GridBagConstraints gbc;
	Actor actor;
	JLabel nameLabel;
	GamePanel gamePanel;
	
	public UserPanel(GamePanel gamePanel, Actor actor){
		setBackground(new Color(128, 128, 0));
		this.actor = actor;
		this.gamePanel = gamePanel;
		
		layout = new GridBagLayout();
		gbc = new GridBagConstraints();
		setLayout(layout);
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.ipadx = 10; gbc.ipady = 10;
		gbc.insets = new Insets(5, 5, 5, 5);
		
		gbc.gridx = 0; gbc.gridy = 0;
		nameLabel = new JLabel(actor.getFullName());
		nameLabel.setHorizontalAlignment(SwingConstants.LEFT);
		add(nameLabel,gbc);
		Border blackline = BorderFactory.createLineBorder(Color.black);
		setBorder(blackline);
	}
	public Actor getActor() {
		return actor;
	}
	public void setActor(Actor actor) {
		this.actor = actor;
	}
	
	public abstract void update();
	public JLabel getNameLabel() {
		return nameLabel;
	}
	public void setNameLabel(JLabel nameLabel) {
		this.nameLabel = nameLabel;
	}
	
}
