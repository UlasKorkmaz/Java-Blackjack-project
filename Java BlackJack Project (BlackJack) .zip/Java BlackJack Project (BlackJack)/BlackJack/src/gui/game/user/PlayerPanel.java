package gui.game.user;

import javax.swing.JLabel;
import javax.swing.SwingConstants;

import actors.Player;
import gui.game.GamePanel;
import materials.Card;
import materials.CardGroup;

public class PlayerPanel extends UserPanel {
	JLabel scoreLabel;
	JLabel statusLabel;
	public PlayerPanel(GamePanel gamePanel, Player player){
		super(gamePanel, player);
		gbc.gridx = 0; gbc.gridy = 1;
		scoreLabel = new JLabel("Score: " + player.getScore());
		scoreLabel.setHorizontalAlignment(SwingConstants.LEFT);
		add(scoreLabel, gbc);
		
		gbc.gridy = 2;
		statusLabel = new JLabel("Status: " + (player.lost() ? "Lost" : "Still can win") );
		add(statusLabel,gbc);
	}

	public void update() {
		scoreLabel.setText("Score: " + ((Player)actor).getScore());
		statusLabel.setText("Status: " + (((Player)actor).lost() ? "Lost" : "Still can win") );
	}
	public JLabel getScoreLabel() {
		return scoreLabel;
	}
	public void setScoreLabel(JLabel scoreLabel) {
		this.scoreLabel = scoreLabel;
	}
	public JLabel getStatusLabel() {
		return statusLabel;
	}
	public void setStatusLabel(JLabel statusLabel) {
		this.statusLabel = statusLabel;
	}
	
}
