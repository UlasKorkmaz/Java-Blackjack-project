package gui.menu;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import gui.MainFrame;

public class SettingsMenu extends JPanel{
	MainFrame mainFrame;
	JButton goBack;
	JLabel pleaseEnter;
	JLabel thisColor;
	JTextField r_textField;
	JTextField g_textField;
	JTextField b_textField;
	JButton change;
	public SettingsMenu(MainFrame mainFrame) {
		super();
		this.mainFrame = mainFrame;
		goBack = new JButton("Go Back");
		goBack.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				mainFrame.getLayout().show(mainFrame.getCards(), MainFrame.mainMenuCard);
			}
		});
		add(goBack);
		pleaseEnter = new JLabel("Please enter R, G, and B values");
		add(pleaseEnter);
		r_textField = new JTextField("128");
		g_textField = new JTextField("0");
		b_textField = new JTextField("0");
		add(r_textField);
		add(g_textField);
		add(b_textField);
		change = new JButton("Change");
		change.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int r  = Integer.parseInt(r_textField.getText());
				int g  = Integer.parseInt(g_textField.getText());
				int b  = Integer.parseInt(b_textField.getText());
				Color color = new Color(r,g,b);
				mainFrame.getGamePanel().getHandPanel().setBackground(color);
				thisColor.setForeground(color);
				thisColor.setBackground(color);
				
			}
		});
		add(change);
		
		thisColor = new JLabel("This Color");
		thisColor.setForeground(new Color(0,128,0));
		thisColor.setBackground(new Color(0,128,0));
		thisColor.setOpaque(true);
		add(thisColor);
	}
}
