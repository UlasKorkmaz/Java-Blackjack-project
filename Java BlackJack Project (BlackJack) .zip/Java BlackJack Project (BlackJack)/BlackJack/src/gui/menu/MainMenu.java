package gui.menu;

import java.awt.CardLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import gui.MainFrame;

public class MainMenu extends JPanel {
	MainFrame mainFrame;
	JButton startGameButton;
	JButton howToPlayButton;
	JButton settingsButton;
	public MainMenu(MainFrame mainFrame){
		
		this.mainFrame  = mainFrame;
		startGameButton = new JButton("Start Game");
		startGameButton.setAlignmentX(CENTER_ALIGNMENT);
		startGameButton.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
		        
				CardLayout mainFrameCardsLayout = ((CardLayout)(mainFrame.getCards().getLayout()));
		           mainFrameCardsLayout.show(mainFrame.getCards(), MainFrame.gamePanelCard);
			}  
		});  
		
		howToPlayButton = new JButton("How To Play");
		howToPlayButton.setAlignmentX(CENTER_ALIGNMENT);
		howToPlayButton.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
		           CardLayout mainFrameCardsLayout = ((CardLayout)(mainFrame.getCards().getLayout()));
		           mainFrameCardsLayout.show(mainFrame.getCards(), MainFrame.howToPlayMenuCard);
			}  
		});
		settingsButton = new JButton("Settings");
		settingsButton.setAlignmentX(CENTER_ALIGNMENT);
		settingsButton.addActionListener(new ActionListener(){  
			public void actionPerformed(ActionEvent e){  
		           CardLayout mainFrameCardsLayout = ((CardLayout)(mainFrame.getCards().getLayout()));
		           mainFrameCardsLayout.show(mainFrame.getCards(), MainFrame.settingsMenuCard);
			}  
		});  
		
		
		setLayout (new BoxLayout (this, BoxLayout.Y_AXIS));
		
		add(Box.createVerticalGlue());
		add(startGameButton);
		add(Box.createVerticalGlue());
		add(howToPlayButton);
		add(Box.createVerticalGlue());
		add(settingsButton);
		add(Box.createVerticalGlue());
		
		//setBackground(Color.BLACK);
		setPreferredSize(new Dimension(300,300));
//		setMinimumSize(new Dimension(300,300));
//		setMaximumSize(new Dimension(300,300));
		setVisible(true);
	}
}
