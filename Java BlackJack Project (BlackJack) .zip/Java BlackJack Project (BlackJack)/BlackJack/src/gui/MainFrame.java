package gui;

import java.awt.BorderLayout;
import java.awt.CardLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;

import gui.game.GamePanel;
import gui.menu.HowToPlayMenu;
import gui.menu.MainMenu;
import gui.menu.SettingsMenu;

public class MainFrame extends JFrame {
	private CardLayout layout;
	private MainMenu mainMenu;
	private GamePanel gamePanel;
	private HowToPlayMenu howToPlayMenu;
	private SettingsMenu settingsMenu;
	private JPanel cards;
	public final static String mainMenuCard = "MainMenuCard";
	public final static String settingsMenuCard = "SettingsMenuCard";
	public final static String gamePanelCard = "GamePanelCard";
	public final static String howToPlayMenuCard = "HowToPlayMenuCard";
	
	
//	private final static MainFrame frame;
//	static {
//		frame = new MainFrame();
//	}
	
	
	public MainFrame(){
		layout = new CardLayout();
		cards = new JPanel(layout);
		
		mainMenu = new MainMenu(this);
		cards.add(mainMenu, mainMenuCard);
		
		gamePanel = new GamePanel(this);
		cards.add(gamePanel, gamePanelCard);
		
		howToPlayMenu = new HowToPlayMenu(this);
		cards.add(howToPlayMenu, howToPlayMenuCard);
		
		settingsMenu = new SettingsMenu(this);
		cards.add(settingsMenu, settingsMenuCard);
		
		add(cards, BorderLayout.CENTER);
		//setSize(new Dimension(700,700));
//		setPreferredSize(new Dimension(700,700));
		layout.show(cards, mainMenuCard);
		
		pack();
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public JPanel getCards() {
		return cards;
	}
	public void setCards(JPanel cards) {
		this.cards = cards;
	}
	public GamePanel getGamePanel() {
		return gamePanel;
	}
	public void setGamePanel(GamePanel gamePanel) {
		this.gamePanel = gamePanel;
	}
	public CardLayout getLayout() {
		return layout;
	}
	public void setLayout(CardLayout layout) {
		this.layout = layout;
	}
//	public static MainFrame getFrame() {
//		return frame;
//	}
	
}
