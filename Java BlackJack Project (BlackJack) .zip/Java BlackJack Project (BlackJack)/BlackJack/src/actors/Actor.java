package actors;

import game.Game;

public abstract class Actor {
	Game game;
	String firstname;
	String lastname;
	Actor(Game game, String firstname, String lastname){
		this.game = game;
		this.firstname = firstname;
		this.lastname = lastname;
	}
	public String getFirstname() {
		return firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getFullName() {
		return firstname + " " + lastname;
	}
}































