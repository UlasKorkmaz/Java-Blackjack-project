package actors;

import java.util.ArrayList;
import java.util.Arrays;

import game.Game;
import materials.Card;

public class Player extends Actor{

	ArrayList<Card> cards = new ArrayList<Card>();
	public Player(Game game, String firstname, String lastname) {
		super(game, firstname, lastname);
	}
	public void drawACard() {
		cards.add(game.getDealer().giveACard());
	}
	public Game getGame() {
		return game;
	}
	public int getScore() {
		int total = 0;
		int ace_count = 0;
		for(Card c : cards) {
			if(c.getValue() == 1)
				ace_count++;
			else if(c.getValue() >= Card.JACK && c.getValue() <= Card.KING )
				total += 10;
			else
				total += c.getValue();
		}
		int[] trivial_arr1 = new int[ace_count];
		int[] trivial_arr2 = new int[ace_count];
		
		int sum1 = total;
		int sum2 = total;
		
		if(ace_count != 0){
			trivial_arr1[0] = Card.ACE;
			trivial_arr2[0] = Card.ACE_SECOND;
			for(int i = 1; i < ace_count; i++)
				trivial_arr1[i] = trivial_arr2[i] = Card.ACE;
			sum1 += Arrays.stream(trivial_arr1).sum();
			sum2 += Arrays.stream(trivial_arr2).sum();
			
		}
		if(sum2 >= Game.MAX_SCORE_PER_TURN)
			return sum1;
		return sum2;
	}
	public ArrayList<Card> getCards() {
		return cards;
	}
	public void setGame(Game game) {
		this.game = game;
	}
	public void setCards(ArrayList<Card> cards) {
		this.cards = cards;
	}
	public boolean lost() {
		if(getScore() > Game.MAX_SCORE_PER_TURN)
			return true;
		return false;
	}
}
