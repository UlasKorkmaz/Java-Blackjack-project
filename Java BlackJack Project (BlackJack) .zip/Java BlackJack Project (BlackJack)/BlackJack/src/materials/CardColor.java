package materials;

public enum CardColor{
	RED,
	BLACK
}
