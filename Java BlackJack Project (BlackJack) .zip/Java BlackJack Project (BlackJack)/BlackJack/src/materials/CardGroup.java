package materials;

public enum CardGroup{
	DIAMOND(1),
	HEART(2),
	CLUB(3),
	SPADE(4);
	int numericValue;
	private CardGroup(int numericValue) {
		this.numericValue = numericValue;
	}
	public int getNumericValue() {
		return numericValue;
	}
}
